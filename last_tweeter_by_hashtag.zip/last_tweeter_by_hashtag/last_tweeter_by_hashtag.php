<?php
/*
Plugin Name: Last tweets by hashtag
Description: Este plugin permite mostrar los últimos tweets por hashtag
Version:  1.0
Author: DIEGO ERNESTO MARÍN
License: GPL2
*/
// create custom plugin settings menu
add_action('admin_menu', 'last_tweets');

function last_tweets() {

	//create new top-level menu
	add_menu_page('Last tweets by hashtag', 'The last tweets', 'administrator', 'last_tweets_page','last_tweets_page','',100);

	//call register settings function
	add_action( 'admin_init', 'register_last_tweets_settings' );
}


function register_last_tweets_settings() {
	//register our settings
	register_setting( 'last_tweets_settings-group', 'opcion_1' );
	register_setting( 'last_tweets_settings-group', 'opcion_2' );
	register_setting( 'last_tweets_settings-group', 'opcion_3' );
	register_setting( 'last_tweets_settings-group', 'opcion_4' );
}

function last_tweets_page() {
?>
<div class="wrap">
<h1>THE LAST TWEETS BY HASHTAG</h1>

<p>Pasos para generar keys y access token en: <a href="https://apps.twitter.com/">https://apps.twitter.com/</a></p>

<form method="post" action="options.php">
	<?php settings_fields( 'last_tweets_settings-group' ); ?>
	<?php do_settings_sections( 'last_tweets_settings-group' ); ?>
	<table class="form-table">
		<tr valign="top">
		<th scope="row">oauth access token</th>
		<td><input type="text" name="opcion_1" value="<?php echo esc_attr( get_option('opcion_1') ); ?>" /></td>
		</tr>
		 
		<tr valign="top">
		<th scope="row">oauth access token secret</th>
		<td><input type="text" name="opcion_2" value="<?php echo esc_attr( get_option('opcion_2') ); ?>" /></td>
		</tr>
		
		<tr valign="top">
		<th scope="row">consumer key</th>
		<td><input type="text" name="opcion_3" value="<?php echo esc_attr( get_option('opcion_3') ); ?>" /></td>
		</tr>

		<tr valign="top">
		<th scope="row">consumer secret</th>
		<td><input type="text" name="opcion_4" value="<?php echo esc_attr( get_option('opcion_4') ); ?>" /></td>
		</tr>



	</table>
	
	<?php submit_button(); ?>

</form>
</div>


<?php } ?>


<?php




//[get_tweets_hashtag]
function get_tweets_hashtagf(){

require_once('TwitterAPIExchange.php');

$settings = array(
    'oauth_access_token' => get_option('opcion_1'),
    'oauth_access_token_secret' => get_option('opcion_2'),
    'consumer_key' => get_option('opcion_3'),
    'consumer_secret' => get_option('opcion_4')
);

$url = 'https://api.twitter.com/1.1/search/tweets.json';
$getfield = '?q=#'.get_post_meta( 17, '_hashtag', true ).'&count=21&tweet_mode=extended';
$requestMethod = 'GET';

$twitter = new TwitterAPIExchange($settings);
$response = $twitter->setGetfield($getfield)
    ->buildOauth($url, $requestMethod)
    ->performRequest();

$json = json_decode($response);

$resultados = $json->statuses;

$contenido = '';
$color = '';

$contenido .= '<h2>THE LAST TWEETS BY HASHTAGS</h2>
  
  <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">Simple collapsible</button>

  <div id="demo" class="collapse">';

if ( count($resultados) > 0 ){
foreach ($resultados as $key => $value) {
	if ($key > 9)
	{
		$color = '#ccc';
	}
	else
	{
		$color = '#0B0B3B';
	}

    $contenido .= '<div class="row"><div class="col-md-2"><img src="'.$value->user->profile_image_url.'"></div><div class="col-md-10" style="color:'.$color.'"> '.$value->full_text.'</div></div>';

	
}

}
else
{
$contenido.= '<p>NO HAY TWEETS DISPONIBLES</p>';	
}

$contenido.= '</div>';


	return $contenido;
}
add_shortcode( 'get_tweets_hashtag', 'get_tweets_hashtagf' );

?>